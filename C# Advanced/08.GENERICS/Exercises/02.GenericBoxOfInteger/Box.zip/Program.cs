﻿namespace _02.GenericBoxOfInteger
{
    using System;

    public class Program
    {
        public static void Main()
        {
            int inputLinesCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < inputLinesCount; i++)
            {
                Box<int> number = new Box<int>();
                number.Element = int.Parse(Console.ReadLine());
                Console.WriteLine(number);
            }
        }
    }
}
