﻿namespace _02.GenericBoxOfInteger
{
    public class Box<T>
    {
        public T Element { get; set; }

        public override string ToString()
        {
            return $"{this.Element.GetType()}: {this.Element}";
        }
    }
}
